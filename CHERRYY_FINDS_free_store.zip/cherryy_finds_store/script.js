let cart = JSON.parse(localStorage.getItem("cherryyCart") || "[]");

const money = n => "PKR " + Number(n).toLocaleString("en-PK");

function renderProducts(){
  const el=document.getElementById("products");
  el.innerHTML=PRODUCTS.map(p=>`
    <article class="product">
      <img src="${p.image}" alt="${p.name}">
      <div class="product-info">
        <h3>${p.name}</h3>
        <p>${p.description}</p>
        <div class="price">${money(p.price)}</div>
        <button class="add" onclick="addToCart('${p.id}')">Add to bag</button>
      </div>
    </article>`).join("");
}
function save(){localStorage.setItem("cherryyCart",JSON.stringify(cart));}
function addToCart(id){
  const item=cart.find(x=>x.id===id);
  if(item)item.qty++;
  else cart.push({id,qty:1});
  save();updateCount();openCart();
}
function updateCount(){document.getElementById("cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0);}
function openCart(){renderCart();document.getElementById("cartModal").classList.remove("hidden");}
function closeCart(){document.getElementById("cartModal").classList.add("hidden");}
function changeQty(id,d){
  const item=cart.find(x=>x.id===id); if(!item)return;
  item.qty+=d;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);
  save();renderCart();updateCount();
}
function renderCart(){
  const box=document.getElementById("cartItems");
  if(!cart.length){box.innerHTML="<p>Your bag is empty ♡</p>";document.getElementById("cartTotal").textContent=money(0);return;}
  let total=0;
  box.innerHTML=cart.map(i=>{
    const p=PRODUCTS.find(x=>x.id===i.id); total+=p.price*i.qty;
    return `<div class="cart-row"><img src="${p.image}" alt=""><div><strong>${p.name}</strong><div class="qty"><button onclick="changeQty('${p.id}',-1)">−</button><span>${i.qty}</span><button onclick="changeQty('${p.id}',1)">+</button></div></div><strong>${money(p.price*i.qty)}</strong></div>`;
  }).join("");
  document.getElementById("cartTotal").textContent=money(total);
}
function checkout(){
  if(!cart.length){alert("Your bag is empty.");return;}
  window.location.href="checkout.html";
}
renderProducts();updateCount();
