# CHERRYY FINDS — Free Store Website

## What is included
- Responsive storefront for laptop + phone
- 5 products with your supplied photos and prices
- Add-to-bag cart saved in the browser
- WhatsApp and Instagram buttons
- Editable `products.js`
- No paid website builder required

## Your products
1. 15 Colors Bedazzling Kit — PKR 2,900
2. 24 Colors Bedazzling Kit — PKR 3,300
3. Viral Flip Digi Cam — PKR 12,500
4. Viral Sliding Digi Cam — PKR 20,000
5. 4K Digi Cam — PKR 12,500

## How to change prices / add products
Open `products.js` in Notepad or VS Code.
Each product has:
- id
- name
- price
- image
- description

To add another product, copy one product block, change the values, and put its image inside the `assets` folder.

## Orders to your Gmail
Checkout uses FormSubmit to send the customer's order form to:
hamzaashrafking111@gmail.com

IMPORTANT: On the first submission, FormSubmit may send an activation/confirmation email to that Gmail. Approve it once. Your Gmail password is NOT stored in this website.

## Put it online for free
Option A: GitHub Pages
1. Create a free GitHub account.
2. Create a new repository.
3. Upload all files/folders from this package.
4. Settings → Pages → deploy from the main branch.
5. GitHub gives you a free website URL.

Option B: Netlify
1. Create a free Netlify account.
2. Drag the `cherryy_finds_store` folder into Netlify's deploy area.
3. It publishes a free site URL.

You own/edit the files. No paid subscription is required for the site itself.

## Your editing access
Everything is in normal HTML/CSS/JavaScript files that you can edit yourself.
- `products.js` = product names, prices, descriptions and image filenames
- `assets/` = product photos
- `style.css` = colors, fonts, spacing and design
- `index.html` = homepage text/sections
- `script.js` = cart behavior
