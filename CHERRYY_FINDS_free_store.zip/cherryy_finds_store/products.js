/* EDIT THIS FILE to change prices, names, photos or add products. */
const PRODUCTS = [
  {
    "id": "bedazzling-15",
    "name": "15 Colors Bedazzling Kit",
    "price": 2900,
    "image": "assets/bedazzling-15.jpg",
    "description": "15 gorgeous colors with 2\u20133 glues, tweezers and a picking stick."
  },
  {
    "id": "bedazzling-24",
    "name": "24 Colors Bedazzling Kit",
    "price": 3300,
    "image": "assets/bedazzling-24.jpg",
    "description": "24 gorgeous colors with 2\u20133 glues, tweezers and a picking stick."
  },
  {
    "id": "flip-digicam",
    "name": "Viral Flip Digi Cam",
    "price": 12500,
    "image": "assets/flip-digicam.jpg",
    "description": "Cute viral flip-style digi cam for aesthetic everyday shots."
  },
  {
    "id": "sliding-digicam",
    "name": "Viral Sliding Digi Cam",
    "price": 20000,
    "image": "assets/sliding-digicam.jpg",
    "description": "Viral sliding digi cam with a sleek, cute retro look."
  },
  {
    "id": "4k-digicam",
    "name": "4K Digi Cam",
    "price": 12500,
    "image": "assets/4k-digicam.jpg",
    "description": "Compact 4K-style digital camera for fun photos and videos."
  }
];
